
package gamemarkstudio.newemployeepane;

import java.io.ByteArrayOutputStream;


public class PersonalInfo {
    
    private int id = 0;
    private String name;
    private String address;
    private String adhar;
    private String phone;
    private String eName;
    private String ePhone;
    private byte[] pic;
    private String dob;
    private String email;
    private ByteArrayOutputStream img;
    private String post;
    private double salary;
    private String timing;
  

    public PersonalInfo(int id, String name, String phone ,String adhar, String eName , String ePhone , String address, String dob , String email ,byte[] pic,
                String post, double sal, String timing) {
        setId(id);
        setName(name);
        setAddress(address);
        setAdhar(adhar);
        setPhone(phone);
        seteName(eName);
        setePhone(ePhone);
        setPic(pic);
        setDob(dob);
        setEmail(email);
        setPost(post);
        setSalary(sal);
        setTiming(timing);
        
        
    }

    public boolean setId(int id) {
       if (id > 0)
         this.id = id;
       else {
         this.id = id *-1;
        throw new IllegalArgumentException("Employee ID must be in positive Integers.");
       }
       return true;
    }

    public void setPost(String post) {
        this.post = post;
    }

    public boolean setSalary(double salary) {
        if(salary > 0)
        this.salary = salary;
        else
         throw new IllegalArgumentException("Salary must be in positive Integers.");
        return true;    
    }

    public void setTiming(String timing) {
        this.timing = timing;
    }
    

    public void setName(String name) {
        this.name = name;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setAdhar(String adhar) {
       
        this.adhar = adhar;

    }

    public void setPhone(String phone) {
         this.phone = phone;
    }

    public void seteName(String eName) {
        this.eName = eName;
    }

    public void setePhone(String ePhone) {
         this.ePhone = ePhone;
        
    }

    public void setPic(byte[] pic) {
        this.pic = pic;  
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
      
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getAdhar() {
        return adhar;
    }

    public String getPhone() {
        return phone;
    }

    public String geteName() {
        return eName;
    }

    public String getePhone() {
        return ePhone;
    }

    public byte [] getPic()
    {
        if(img != null)
             return img.toByteArray();
        else 
            return pic;
    }

    public String getDob() {
        return dob;
    }

    public String getEmail() {
        return email;
    }

    public String getPost() {
        return post;
    }

    public double getSalary() {
        return salary;
    }

    public String getTiming() {
        return timing;
    }
    
    
  
    
    
    
}
